
  
Hi there, It's a full-stack app built in React.js for the frontend and Node.js for the backend. And I've used Mongodb's atlas as a cloud service provider to store data. This app is a simple TODO APP, this is just to showcase the basic working of a Full-stack application built in MERN. This app includes all the CRUD operations performed via exposed APIs
Frontend -
react-bootstrap : for frontend CSS framework
Backend -
express-validator - Input validation
mongoose - ODM
express - node.js framework


To run this project follow these steps:

npm start
npm test
npm run build
npm run eject
npm run build

Well, first clone or download this repo.
Create a cluster in mongodb Atlas, and then create a collection, and get your access URL to your cluster's database and paste it in app.js for MONGODBURL variable.
In Root folder, Run npm install to install dependent packages for the Node.js server.
In Client folder, Run npm install to install dependent packages for the React app.
